# X-Trader.cloud-Signal
Segnali Crypto json
